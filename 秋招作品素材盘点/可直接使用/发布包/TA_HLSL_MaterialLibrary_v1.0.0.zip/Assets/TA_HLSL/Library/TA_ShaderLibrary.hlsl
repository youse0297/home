//UNITY_SHADER_NO_UPGRADE
#ifndef TA_SHADER_LIBRARY_INCLUDED
#define TA_SHADER_LIBRARY_INCLUDED

#include "TA_ShaderTypes.hlsl"
#include "TA_Common.hlsl"
#include "TA_Vector.hlsl"
#include "TA_EdgeWear.hlsl"
#include "TA_ProceduralMask.hlsl"
#include "TA_SnowCover.hlsl"
#include "TA_Sampling.hlsl"
#include "TA_NormalBlend.hlsl"
#include "TA_VertexDisplacement.hlsl"
#include "TA_VertexAnimation.hlsl"
#include "TA_VertexDeformation.hlsl"
#include "TA_PBRInput.hlsl"
#include "TA_BRDF.hlsl"
#include "TA_TransparencyRefraction.hlsl"
#include "TA_Anisotropy.hlsl"
#include "TA_Lighting.hlsl"
#include "TA_MaterialInterface.hlsl"
#include "TA_DebugViews.hlsl"

#endif
